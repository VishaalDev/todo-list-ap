package com.example.flutter_todolist_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
