
import 'package:flutter/material.dart';

Color tdYellowColor = const Color.fromARGB(255, 191, 150, 27);
Color tdDarkBlueColor = Color.fromARGB(255, 9, 29, 129);
Color tdBgColor = Colors.white;

Color tdBlackColor = Colors.black;
Color tdGreyColor = Color.fromARGB(255, 187, 187, 187);