import 'package:flutter/material.dart';
import 'package:flutter_todolist_app/component/colors.dart';
import 'package:flutter_todolist_app/widgets/toDoItems.dart';

class homeScreen extends StatefulWidget {
  const homeScreen({super.key});

  @override
  State<homeScreen> createState() => _homeScreenState();
}

class _homeScreenState extends State<homeScreen> {
  List<ToDo> _foundToDo = [];
  @override
  void initState() {
    _foundToDo = toDoListItems;
    super.initState();
  }

  final toDoListItems = ToDo.toDoList();
  final _todoController = TextEditingController();
  void _toggleToChange(ToDo todoItem) {
    setState(() {
      todoItem.isDone = !todoItem.isDone;
    });
  }

  void _deleteItemsForToDo(String idToDo) {
    setState(() {
      toDoListItems.removeWhere((item) => item.id == idToDo);
    });
  }

  void _addItemsForToDo(String newTodo) {
    setState(() {
      toDoListItems.add(ToDo(
              id: DateTime.now().millisecondsSinceEpoch.toString(),
              toDoText: newTodo)
          );
      _todoController.clear();
    });
  }

  void _searchObject(String enteredKeyWords) {
    List<ToDo> result = [];
    if (enteredKeyWords.isEmpty) {
      result = toDoListItems;
    } else {
      result = toDoListItems
          .where((itemTodo) => itemTodo.toDoText
              .toLowerCase()
              .contains(enteredKeyWords.toLowerCase()))
          .toList();
    }
    setState(() {
      _foundToDo = result;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          appBar: AppBar(
            elevation: 0.0,
            backgroundColor: tdBgColor,
            leading: Icon(
              Icons.menu,
              color: tdBlackColor,
              size: 30,
            ),
            actions: <Widget>[
             Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: CircleAvatar(
                  child: Image(
                    image: AssetImage('assets/image/avatar.jpg'),
                    fit: BoxFit.cover,
                  ),
                ),
              )
            ],
          ),
          body: Stack(
            children: <Widget>[
              
              Center(
                child: Column(children: <Widget>[
                  Search( onchanged: (value) {
                        _searchObject(value);
                      },),
                  Expanded(
                    child: ListView(
                      children: <Widget>[
                        Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 30),
                            child: Text(
                              "Todo List ",
                              style:
                                  TextStyle(color: tdBlackColor, fontSize: 25,fontWeight: FontWeight.bold),
                            )),
                        for (ToDo todoItems in _foundToDo.reversed)
                          
                          toDoItems(
                            onDeleteItem: _deleteItemsForToDo,
                            onToDoChanged: _toggleToChange,
                            todoItem: todoItems,
                            
                          ),
                      ],
                    ),
                  )
                ]),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Row(children: <Widget>[
                  Expanded(
                      child: Container(
                    margin: EdgeInsets.only(
                        top: 20, right: 10, bottom: 20, left: 20),
                    decoration: BoxDecoration(
                        color: tdBgColor,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                        boxShadow: [
                          BoxShadow(
                              color: tdGreyColor,
                              blurRadius: 10.0,
                              offset: Offset(0, 0),
                              spreadRadius: 0.0)
                        ]),
                    child: TextFormField(
                      controller: _todoController,
                      decoration: InputDecoration(
                          hintText: "Add A New Task",
                          hintStyle: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold),
                          border:
                              OutlineInputBorder(borderSide: BorderSide.none)),
                    ),
                  )),
                  Container(
                    margin: EdgeInsets.only(right: 20),
                    width: 55,
                    height: 55,
                    decoration: BoxDecoration(
                        color: tdDarkBlueColor,
                        borderRadius: BorderRadius.all(Radius.circular(15))),
                    child: IconButton(
                      onPressed: () {
                        _addItemsForToDo(_todoController.text);
                      },
                      icon: Icon(
                        Icons.add,
                        color: tdBgColor,
                        size: 30,
                      ),
                    ),
                  )
                ]),
              )
            ],
          )),
    );
  }
}

class Search extends StatelessWidget {
  final Function(String) onchanged;
  const Search({super.key,required this.onchanged});
  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.only(top: 20, left: 20, right: 20),
        height: 45,
        alignment: Alignment.bottomCenter,
        decoration: BoxDecoration(
            border: Border.all(color: tdGreyColor),
            color: tdBgColor,
            borderRadius: BorderRadius.all(Radius.circular(20))),
        child: TextFormField(
          onChanged: onchanged,
          textAlignVertical: TextAlignVertical.bottom,
          decoration: InputDecoration(
              hintText: "Search",
              prefixIcon: Icon(Icons.search_rounded),
              prefixIconColor: tdGreyColor,
              border: OutlineInputBorder(borderSide: BorderSide.none)),
        ));
  }
}
